from django.shortcuts import render
from posts.models import Post,Category

from django.db.models import Q

def home(request):
    search_data=request.GET.get('search') if request.GET.get('search') !=None else''
    print(search_data)
    data = Post.objects.filter(Q(category__name__icontains=search_data)|Q(title__icontains=search_data))
    
    return render(request, 'home.html', {'data': data})